module.exports = {
  dist: 'dist'
}
