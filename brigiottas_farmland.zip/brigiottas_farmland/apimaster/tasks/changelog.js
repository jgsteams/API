module.exports = {
  options: {
    dest: 'CHANGELOG.md'
  }
}
