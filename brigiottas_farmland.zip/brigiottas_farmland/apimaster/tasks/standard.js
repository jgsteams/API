module.exports = {
  app: {
    src: [
      '{,lib/,tasks/}*.js'
    ]
  }
}
