module.exports = {
  options: {
    banner: '<%= banner %>',
    stripBanners: true
  },
  dist: {
    src: ['dist/api.js'],
    dest: 'dist/api.js'
  }
}
