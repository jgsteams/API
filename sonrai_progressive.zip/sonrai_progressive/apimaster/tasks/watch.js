module.exports = {
  lib: {
    files: ['{,lib/,tasks/}*.js'],
    tasks: [
      'build'
    ]
  }
}
